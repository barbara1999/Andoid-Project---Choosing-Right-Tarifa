package com.example.choosingrighttarifa;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    private Button startButton;
    private Button tariffButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        startButton=(Button) findViewById(R.id.idStartButton);
        tariffButton=(Button) findViewById(R.id.idTarifeButton);


        startButton.setText(R.string.start_button_text);
        tariffButton.setText(R.string.tarife);

        tariffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTariffActivity();
            }
        });

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalculatingActivity();

            }
        });


    }

    public void openTariffActivity(){
        Intent intent=new Intent(this,TariffActivity.class);
        startActivity(intent);
    }

    public void openCalculatingActivity(){
        Intent intent=new Intent(this,CalculatingActivity.class);
        startActivity(intent);
    }
}
