package com.example.choosingrighttarifa;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private Context context;
    private List<ListItem> listItems;


    public RecyclerAdapter(Context context, List listitem) {
        this.context = context;
        this.listItems = listitem;

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_tariff, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.ViewHolder holder, int position) {
        ListItem item= listItems.get(position);

        holder.name.setText(item.getName());
        holder.price.setText(item.getPrice());
        holder.sms.setText(item.getSms());
        holder.Internet.setText(item.getInternet());
        holder.call.setText(item.getCall());

    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public TextView price;
        public TextView sms;
        public TextView Internet;
        public TextView call;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            name = (TextView) itemView.findViewById(R.id.title);
            price = (TextView) itemView.findViewById(R.id.price);
            sms=(TextView) itemView.findViewById(R.id.sms);
            Internet=(TextView) itemView.findViewById(R.id.internet);
            call=(TextView) itemView.findViewById(R.id.call);

        }
    }

}
