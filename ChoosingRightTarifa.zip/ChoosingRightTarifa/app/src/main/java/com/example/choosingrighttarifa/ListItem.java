package com.example.choosingrighttarifa;

public class ListItem {

    private String name;
    private String price;
    private String sms;
    private String Internet;
    private String call;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getSms() {
        return sms;
    }

    public void setSms(String sms) {
        this.sms =sms;
    }

    public String getInternet() {
        return Internet;
    }

    public void setInternet(String internet) {
        Internet = internet;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCall() {
        return call;
    }

    public void setCall(String call) {
        this.call = call;
    }

    public ListItem(String name, String price, String sms, String Internet, String call) {
        this.name=name;
        this.price=price;
        this.sms=sms;
        this.Internet=Internet;
        this.call=call;
    }


}
