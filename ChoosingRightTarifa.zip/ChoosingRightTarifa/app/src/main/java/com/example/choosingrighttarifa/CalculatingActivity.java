package com.example.choosingrighttarifa;

public class CalculatingActivity {
}
