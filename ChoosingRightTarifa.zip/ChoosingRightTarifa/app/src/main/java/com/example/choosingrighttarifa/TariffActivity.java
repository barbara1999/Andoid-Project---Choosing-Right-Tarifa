package com.example.choosingrighttarifa;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TariffActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tariff);

        recyclerView=(RecyclerView) findViewById(R.id.recyclerViewID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        listItems=new ArrayList<>();

        ListItem Tarifa1=new ListItem("Strimalica","139kn","1500sms","10GB","1500min");
        ListItem Tarifa2=new ListItem("Surferica","99kn","1000sms","7GB","1000min");
        ListItem Tarifa3=new ListItem("Sheralica","79kn","500sms","4GB","500min");
        ListItem Tarifa4=new ListItem("Spikalica","49kn","300sms","1GB","300min");

        listItems.add(Tarifa1);
        listItems.add(Tarifa2);
        listItems.add(Tarifa3);
        listItems.add(Tarifa4);


        adapter=new RecyclerAdapter(this,listItems);
        recyclerView.setAdapter(adapter);

    }
}
